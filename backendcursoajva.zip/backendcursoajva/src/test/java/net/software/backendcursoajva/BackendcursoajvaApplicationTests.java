package net.software.backendcursoajva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendcursoajvaApplicationTests {

	@Test
	void contextLoads() {
	}

}
